const array_name = [apple, car]; 
console.log(typeof array_name); 