let arr = [1, 2, 3, 4];
const output = arr.reduce((res, curr) => {
    return res + curr;
}, 0);  // Initial value is set to 0
console.log(output);  // Output: 10
