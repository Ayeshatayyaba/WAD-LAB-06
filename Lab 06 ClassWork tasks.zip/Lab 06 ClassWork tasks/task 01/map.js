
// create a new array
let nums=[67,52,39];
let newArr= nums.map((val)=>{
    return val;
});
console.log(newArr);
let calcSquare = (num) =>{
    console.log(num*num);
};