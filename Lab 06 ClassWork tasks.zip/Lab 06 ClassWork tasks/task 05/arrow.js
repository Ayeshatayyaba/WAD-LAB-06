const printHello = () => {
    console.log("hello");
}
