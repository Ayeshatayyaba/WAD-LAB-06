const cars = new Array("Saab", "Volvo", "BMW");
console.log(typeof cars);