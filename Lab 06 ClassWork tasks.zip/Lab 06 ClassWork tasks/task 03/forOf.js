let text = "Hello";

for (let char of text) {
    console.log(char);
}
