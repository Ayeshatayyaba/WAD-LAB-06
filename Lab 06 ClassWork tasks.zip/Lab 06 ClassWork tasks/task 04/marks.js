let marks=[65,97,78,60,37,44];
let sum=0;
for(let val of marks){
    sum+=val;
}
let avg=sum/marks.length;
console.log(`avg marks of the class=${avg}`);
let items=[250,645,300,900,50];
let i=0;
for(let val of items){
    console.log(`value at index=${i}=${val}`);
i++;
}