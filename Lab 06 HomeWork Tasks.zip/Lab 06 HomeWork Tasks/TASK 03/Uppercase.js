let words = ["hello", "world", "javascript", "loops"];
let upperCaseWords = [];

for (let word of words) {
    upperCaseWords.push(word.toUpperCase());  // Convert to uppercase and add to the new array
}

console.log("Uppercase words:", upperCaseWords);

