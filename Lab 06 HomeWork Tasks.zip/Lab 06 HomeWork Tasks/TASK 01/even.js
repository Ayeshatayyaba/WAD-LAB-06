let nums = [10, 15, 20, 25, 30];
let evenNumbers = [];

for (let num of nums) {
    if (num % 2 === 0) {  // Check if the number is even
        evenNumbers.push(num);  // Add even number to the array
    }
}

console.log("Even numbers:", evenNumbers);  // Output: Even numbers: [10, 20, 30]
