let students = [45, 78, 32, 90, 51, 47, 60, 85];
// Filtering marks greater than 50
let filteredMarks = students.filter(mark => mark > 50);
console.log("Marks greater than 50:", filteredMarks);
