let nums = [12, 45, 3, 78, 29, 6];

let max = nums[0];  // Assume first element is the maximum
let min = nums[0];  // Assume first element is the minimum

for (let num of nums) {
    if (num > max) {
        max = num;  // Update max if current number is greater
    }
    if (num < min) {
        min = num;  // Update min if current number is smaller
    }
}

console.log("Maximum number:", max);  // Output: Maximum number: 78
console.log("Minimum number:", min);  // Output: Minimum number: 3
