// Array of Software House names
let softwareHouses = ["TechSoft", "CodeLabs", "SoftZone", "DevNest", "WebWorks"];
console.log("Original Array:", softwareHouses);

// Remove the first name
softwareHouses.shift();
console.log("After removing the first name:", softwareHouses);

// Replace middle name with a new name
softwareHouses[Math.floor(softwareHouses.length / 2)] = "AppMinds";
console.log("After replacing the middle name:", softwareHouses);

// Add a new name at the end
softwareHouses.push("CodeCraft");
console.log("After adding a new name at the end:", softwareHouses);
