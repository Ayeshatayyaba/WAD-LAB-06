const countVowels = (str) => {
    const vowels = "aeiouAEIOU";
    return [...str].filter(char => vowels.includes(char)).length;
};
let result = countVowels("Programming is Fun!");
console.log("Number of vowels:", result);  
