function countVowels(str) {
    let vowels = "aeiouAEIOU";  
    let count = 0;

    for (let char of str) {  // Loop through each character in the string
        if (vowels.includes(char)) {  // Check if the character is a vowel
            count++;
        }
    }
    return count;
}
let result = countVowels("Hello World");
console.log("Number of vowels:", result);  
