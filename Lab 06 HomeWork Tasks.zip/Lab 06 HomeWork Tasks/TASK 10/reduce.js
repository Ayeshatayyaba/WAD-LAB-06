// Array of numbers
let numbers = [2, 3, 4, 5];

// Using reduce() to calculate the product
let product = numbers.reduce((acc, curr) => acc * curr, 1);

console.log("Product of all numbers:", product);
